
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'shehanp12',
  applicationName: 'backend',
  appUid: 'dVCTTKR7n2KSNmH2XT',
  orgUid: 'c81da065-b777-4a43-a3f1-45f870a9d6f8',
  deploymentUid: 'c6e4a6e5-2236-4887-b31f-bd2814fd7ebe',
  serviceName: 'libraryManagmentSystem',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'prod',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.6',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'libraryManagmentSystem-prod-billing', timeout: 6 };

try {
  const userHandler = require('./billing.js');
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}